charmhelpers.core.templating
============================

.. automodule:: charmhelpers.core.templating
    :members:
    :undoc-members:
    :show-inheritance:
