charmhelpers.contrib.templating package
=======================================

charmhelpers.contrib.templating.contexts module
-----------------------------------------------

.. automodule:: charmhelpers.contrib.templating.contexts
    :members:
    :undoc-members:
    :show-inheritance:

charmhelpers.contrib.templating.pyformat module
-----------------------------------------------

.. automodule:: charmhelpers.contrib.templating.pyformat
    :members:
    :undoc-members:
    :show-inheritance:


.. automodule:: charmhelpers.contrib.templating
    :members:
    :undoc-members:
    :show-inheritance:
